# PromptParle PowerShell Module

**Trim the prompt. Keep the signal.**

Client for the [PromptParle](https://promptparle.com) API — optimize context, mask secrets, and route to OpenAI, Claude, Gemini, or Grok.

## Install

### Option A — copy into your modules path (recommended)

**Windows (PowerShell 5.1 or 7):**

```powershell
$dest = "$env:USERPROFILE\Documents\PowerShell\Modules\PromptParle"
# Windows PowerShell 5.1:
# $dest = "$env:USERPROFILE\Documents\WindowsPowerShell\Modules\PromptParle"

New-Item -ItemType Directory -Force -Path $dest | Out-Null
Copy-Item -Recurse -Force .\powershell\PromptParle\* $dest
Import-Module PromptParle -Force
```

**Linux / macOS (PowerShell 7):**

```powershell
$dest = "$HOME/.local/share/powershell/Modules/PromptParle"
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Copy-Item -Recurse -Force ./powershell/PromptParle/* $dest
Import-Module PromptParle -Force
```

### Option B — import from the repo

```powershell
Import-Module ./powershell/PromptParle/PromptParle.psd1 -Force
```

### Option C — install script

From the repo root (or this folder):

```powershell
./powershell/Install-PromptParle.ps1
```

## Setup

1. Create an account at https://promptparle.com and verify email  
2. **Providers** → add OpenAI / Claude / Gemini / Grok key  
3. **API Keys** → create a desktop key (`pp_live_…`)  
4. Configure the module:

```powershell
Set-PromptParleApiKey -ApiKey 'pp_live_xxxxx'
Get-PromptParleConfig
```

Config is stored at `~/.promptparle/config.json` (or `%USERPROFILE%\.promptparle\config.json`).

Environment overrides:

| Variable | Purpose |
|----------|---------|
| `PROMPTPARLE_API_KEY` | Desktop API key |
| `PROMPTPARLE_BASE_URL` | Default `https://promptparle.com` |
| `PROMPTPARLE_CONFIG_DIR` | Override config directory |

## Commands

| Command | Description |
|---------|-------------|
| `Set-PromptParleApiKey` | Save `pp_live_…` key |
| `Get-PromptParleConfig` | Show config (key masked) |
| `Get-PromptParleProvider` | List providers + which keys are set |
| `Get-PromptParleUsage` | Token savings summary |
| `Invoke-PromptParle` | Optimize + call AI (or optimize only) |
| `Invoke-PromptParleSecurityReview` | Same with `security-review` profile |

## Examples

```powershell
# Basic
Invoke-PromptParle -Provider openai -Prompt 'Explain this script' -Path .\deploy.ps1

# Pipeline context (logs / configs / code)
Get-Content .\firewall-rules.txt -Raw |
  Invoke-PromptParle `
    -Provider openai `
    -Profile security-review `
    -Prompt 'Find risky firewall rules and recommend safer alternatives'

# Optimize only (no provider call, no AI spend)
Invoke-PromptParle -Provider openai -Prompt 'Clean this up' -Path .\huge.log -OptimizeOnly

# Claude
Invoke-PromptParle -Provider anthropic -Model 'claude-sonnet-4-20250514' `
  -Profile developer -Prompt 'Review for bugs' -Path .\app.py

# Capture result
$r = Invoke-PromptParle -Provider openai -Prompt 'Summarize' -Context $text -Quiet
$r.Response
$r.Metadata.token_reduction_percent

# Usage
Get-PromptParleUsage
Get-PromptParleUsage -Recent
Get-PromptParleProvider
```

## Profiles

`general` · `developer` · `security-review` · `log-analysis` · `documentation` · `executive-summary`

## Output

Default return object:

```text
Response   - AI text (or omitted when -OptimizeOnly)
OptimizedPrompt - when -OptimizeOnly
Metadata   - original_tokens, optimized_tokens, reduction, secrets_masked, ...
Provider / Model / Profile
```

Host banner (unless `-Quiet`):

```text
PromptParle optimized your context:
  Original tokens : 18450
  Optimized tokens: 6230
  Reduction       : 66%
  ...
AI Response:
...
```

## Requirements

- PowerShell 5.1+ or PowerShell 7+
- Network access to `https://promptparle.com`
- Verified PromptParle account + desktop API key
- At least one provider key in the portal (for full AI calls)
